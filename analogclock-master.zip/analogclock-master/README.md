Preview Of Analog Clock:
![37210512-ca30de25ef21ddffe494eaae809994c3](https://user-images.githubusercontent.com/88980866/219699047-10140c94-0010-4f4c-a3e3-dbc49acb8033.png)
